/**
 * Quick Scan scoring engine.
 * This mirrors EXACTLY the formula implemented client-side in
 * AQII_front/js/quick-scan.js -> computePrediction()
 * so that backend predictions stay consistent with what the
 * frontend previously computed locally.
 */

const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function computeAqi({ co2, temperature, humidity, occupancy, windowStatus, month }) {
  let score = 26;
  score += Math.max(0, co2 - 650) * 0.032;
  score += Math.max(0, humidity - 45) * 1.1;
  score += Math.max(0, occupancy - 3) * 8;
  score += Math.max(0, Math.abs(temperature - 22)) * 2.2;

  if (windowStatus === 'Closed') score += 18;
  if (windowStatus === 'Closed' && co2 >= 1000) score += 16;
  if (humidity >= 60) score += 9;
  if (occupancy >= 6) score += 9;
  if (['January', 'February', 'December'].includes(month)) score += 5;
  if (['June', 'July', 'August'].includes(month)) score += 3;

  return clamp(Math.round(score), 20, 170);
}

function statusFromAqi(aqi) {
  if (aqi < 50) return 'GOOD';
  if (aqi < 80) return 'MODERATE';
  if (aqi < 110) return 'BAD';
  return 'DANGEROUS';
}

const STATUS_TEXT = {
  GOOD: 'Clean indoor air is holding steady with balanced ventilation.',
  MODERATE: 'Air quality is acceptable, but ventilation and monitoring are recommended.',
  BAD: 'Air quality is elevated and needs attention to keep conditions comfortable.',
  DANGEROUS: 'Air quality is unsafe. Immediate ventilation or evacuation is recommended.'
};

const SUMMARY_HEADING = {
  GOOD: 'Clean air',
  MODERATE: 'Stable with watch',
  BAD: 'Attention needed',
  DANGEROUS: 'Immediate action'
};

function buildRecommendations({ co2, humidity, occupancy, temperature, windowStatus, aqi, status }) {
  const recommendations = [];
  const softMaintenance = [
    {
      title: 'Light airflow check',
      text: 'Keep gentle circulation running to preserve steady indoor freshness and avoid stagnant air.',
      icon: 'ti ti-refresh-dot'
    },
    {
      title: 'Temperature balance',
      text: 'Maintain comfortable thermal levels and keep vents unobstructed for stable room conditions.',
      icon: 'ti ti-temperature'
    }
  ];

  if (co2 >= 900) {
    recommendations.push({
      title: 'Ventilate more often',
      text: `CO2 is elevated at ${co2} ppm. Open windows or increase fresh-air exchange to dilute buildup.`,
      icon: 'ti ti-wind'
    });
  }

  if (windowStatus === 'Closed' && (co2 >= 900 || aqi >= 60)) {
    recommendations.push({
      title: 'Airflow reset',
      text: 'Fresh air is restricted while the room is under stress. Open windows or activate ventilation to recover indoor quality.',
      icon: 'ti ti-window-open'
    });
  }

  if (humidity >= 55) {
    recommendations.push({
      title: 'Reduce moisture',
      text: `Humidity is ${humidity}%. Use airflow, dehumidification, or moisture control to bring conditions back down.`,
      icon: 'ti ti-droplet-half'
    });
  }

  if (occupancy >= 5) {
    recommendations.push({
      title: 'Lower crowding',
      text: `Occupancy is ${occupancy}. Reduce density or rotate people so heat and CO2 don't build up as quickly.`,
      icon: 'ti ti-users'
    });
  }

  if (aqi >= 70) {
    recommendations.push({
      title: 'Use filtration',
      text: `AQI is elevated at ${aqi}. Run a purifier or boost ventilation until readings recover.`,
      icon: 'ti ti-filter'
    });
  }

  if (status === 'GOOD') {
    softMaintenance.forEach((item) => recommendations.push(item));
  } else if (status === 'MODERATE') {
    recommendations.push({
      title: 'Monitor room trends',
      text: 'Keep checking airflow and occupancy patterns so the room stays comfortable through the day.',
      icon: 'ti ti-chart-arcs'
    });
    recommendations.push({
      title: 'Check moisture levels',
      text: 'Humidity is affecting comfort; adjust ventilation or damp control to stabilize the space.',
      icon: 'ti ti-droplet'
    });
  } else if (status === 'BAD' || status === 'DANGEROUS') {
    recommendations.push({
      title: 'Act now',
      text: 'The room needs immediate fresh-air correction to bring readings back toward safe levels.',
      icon: 'ti ti-alert-triangle'
    });
    recommendations.push({
      title: 'Limit crowding',
      text: 'Reduce occupant load and keep doors or vents open to quickly release trapped air.',
      icon: 'ti ti-user-x'
    });
  }

  const prioritized = [];
  const seen = new Set();
  recommendations.forEach((item) => {
    if (!seen.has(item.title)) {
      seen.add(item.title);
      prioritized.push(item);
    }
  });

  if (status === 'GOOD') return prioritized.slice(0, 2);
  if (status === 'MODERATE') return prioritized.slice(0, 3);
  return prioritized.slice(0, 4);
}

function metaStatus({ co2, temperature, humidity }) {
  return {
    co2Status: co2 < 900 ? 'Fresh' : co2 < 1200 ? 'Watch' : 'High',
    temperatureStatus: temperature < 20 ? 'Cool' : temperature < 26 ? 'Stable' : 'Warm',
    humidityStatus: humidity < 35 ? 'Dry' : humidity < 60 ? 'Balanced' : 'Humid'
  };
}

/**
 * Validates and normalizes raw input coming from the Quick Scan form.
 * Throws an Error with .status = 400 on invalid input.
 */
function validateInput(body) {
  const co2 = Number(body.co2);
  const temperature = Number(body.temperature);
  const humidity = Number(body.humidity);
  const occupancy = Number(body.occupancy);
  const windowStatus = body.windowStatus;
  const month = body.month;

  const errors = [];
  if (Number.isNaN(co2)) errors.push('co2 must be a number');
  if (Number.isNaN(temperature)) errors.push('temperature must be a number');
  if (Number.isNaN(humidity)) errors.push('humidity must be a number');
  if (Number.isNaN(occupancy)) errors.push('occupancy must be a number');
  if (!['Open', 'Closed'].includes(windowStatus)) errors.push('windowStatus must be "Open" or "Closed"');
  if (!MONTHS.includes(month)) errors.push(`month must be one of: ${MONTHS.join(', ')}`);

  if (errors.length) {
    const err = new Error(errors.join('; '));
    err.status = 400;
    throw err;
  }

  return { co2, temperature, humidity, occupancy, windowStatus, month };
}

/**
 * Runs a full Quick Scan prediction matching the frontend's
 * computePrediction() output shape (aqi, status, summary, metrics, recommendations).
 */
function predictQuickScan(rawInput) {
  const input = validateInput(rawInput);
  const aqi = computeAqi(input);
  const status = statusFromAqi(aqi);
  const percentage = (aqi / 170) * 100;
  const recommendations = buildRecommendations({ ...input, aqi, status });
  const meta = metaStatus(input);

  return {
    aqi,
    status,
    percentage,
    summary: {
      heading: SUMMARY_HEADING[status],
      text: STATUS_TEXT[status]
    },
    metrics: {
      co2: { value: input.co2, unit: 'ppm', status: meta.co2Status },
      temperature: { value: input.temperature, unit: '°C', status: meta.temperatureStatus },
      humidity: { value: input.humidity, unit: '%', status: meta.humidityStatus }
    },
    recommendations,
    shouldSpeakAlert: status === 'DANGEROUS',
    input
  };
}

module.exports = {
  MONTHS,
  clamp,
  computeAqi,
  statusFromAqi,
  buildRecommendations,
  validateInput,
  predictQuickScan
};
