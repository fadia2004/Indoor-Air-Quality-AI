/**
 * Room Comparison scoring engine.
 * Mirrors EXACTLY the formula implemented client-side in
 * AQII_front/js/compare.js -> calculateRoomScore() / getRecommendationForAQI()
 */

const { MONTHS, clamp } = require('./quickScanService');

function calculateRoomScore(inputs, fallbackIndex) {
  const co2 = Number(inputs.co2);
  const temperature = Number(inputs.temperature);
  const humidity = Number(inputs.humidity);
  const occupancy = Number(inputs.occupancy);
  const windowStatus = inputs.windowStatus;
  const month = inputs.month;

  let score = 26;
  score += Math.max(0, co2 - 650) * 0.032;
  score += Math.max(0, humidity - 45) * 1.05;
  score += Math.max(0, occupancy - 3) * 8;
  score += Math.max(0, Math.abs(temperature - 22)) * 2.1;
  if (windowStatus === 'Closed') score += 18;
  if (windowStatus === 'Closed' && co2 >= 1000) score += 16;
  if (humidity >= 60) score += 9;
  if (occupancy >= 6) score += 9;
  if (['January', 'February', 'December'].includes(month)) score += 5;
  if (['June', 'July', 'August'].includes(month)) score += 3;

  const aqi = clamp(Math.round(score), 20, 170);
  let status = 'Good';
  if (aqi >= 90) status = 'Poor';
  else if (aqi >= 50) status = 'Moderate';

  const recommendations = [];
  if (co2 >= 900) recommendations.push('Increase fresh air exchange');
  if (humidity >= 60) recommendations.push('Reduce moisture');
  if (occupancy >= 6) recommendations.push('Lower crowding or rotate use');
  if (windowStatus === 'Closed') recommendations.push('Open windows or boost ventilation');
  if (aqi >= 90) recommendations.push('Use filtration or schedule airflow checks');
  if (!recommendations.length) {
    recommendations.push('Maintain steady ventilation');
    recommendations.push('Keep monitoring conditions');
  }

  return {
    name: inputs.name || `Room ${fallbackIndex}`,
    co2,
    temperature,
    humidity,
    occupancy,
    windowStatus,
    month,
    aqi,
    status,
    recommendations: recommendations.slice(0, 3)
  };
}

function getRecommendationForAQI(aqi) {
  if (aqi < 50) {
    return {
      status: 'Good',
      recommendation: 'Maintain current ventilation and keep monitoring the room conditions.'
    };
  }
  if (aqi <= 100) {
    return {
      status: 'Moderate',
      recommendation: 'Increase airflow, monitor CO2 and humidity, and reduce crowding if possible.'
    };
  }
  return {
    status: 'Poor',
    recommendation: 'Improve ventilation immediately, reduce occupancy, and check filtration performance.'
  };
}

function validateRoomInput(body) {
  const co2 = Number(body.co2);
  const temperature = Number(body.temperature);
  const humidity = Number(body.humidity);
  const occupancy = Number(body.occupancy);
  const windowStatus = body.windowStatus;
  const month = body.month;

  const errors = [];
  if (Number.isNaN(co2)) errors.push('co2 must be a number');
  if (Number.isNaN(temperature)) errors.push('temperature must be a number');
  if (Number.isNaN(humidity)) errors.push('humidity must be a number');
  if (Number.isNaN(occupancy)) errors.push('occupancy must be a number');
  if (!['Open', 'Closed'].includes(windowStatus)) errors.push('windowStatus must be "Open" or "Closed"');
  if (!MONTHS.includes(month)) errors.push(`month must be one of: ${MONTHS.join(', ')}`);

  if (errors.length) {
    const err = new Error(errors.join('; '));
    err.status = 400;
    throw err;
  }

  return { co2, temperature, humidity, occupancy, windowStatus, month, name: body.name };
}

/**
 * Analyzes a single room (used by the "Add Room" form on compare.html).
 */
function analyzeRoom(rawInput, fallbackIndex = 1) {
  const input = validateRoomInput(rawInput);
  return calculateRoomScore(input, fallbackIndex);
}

/**
 * Analyzes a full batch of rooms at once and returns aggregate
 * best/worst room info + per-room recommendation cards, matching
 * what compare.js builds client-side from the `rooms` array.
 */
function analyzeRoomBatch(roomsInput) {
  if (!Array.isArray(roomsInput) || roomsInput.length === 0) {
    const err = new Error('rooms must be a non-empty array');
    err.status = 400;
    throw err;
  }

  const rooms = roomsInput.map((room, idx) => analyzeRoom(room, idx + 1));

  const bestRoom = rooms.reduce((best, current) => (current.aqi < best.aqi ? current : best), rooms[0]);
  const worstRoom = rooms.reduce((worst, current) => (current.aqi > worst.aqi ? current : worst), rooms[0]);

  const recommendationCards = rooms.map((room) => {
    const rec = getRecommendationForAQI(room.aqi);
    return {
      roomName: room.name,
      aqi: room.aqi,
      status: rec.status,
      recommendation: rec.recommendation
    };
  });

  return {
    rooms,
    savedRoomCount: rooms.length,
    bestRoom: { name: bestRoom.name, aqi: bestRoom.aqi },
    worstRoom: { name: worstRoom.name, aqi: worstRoom.aqi },
    recommendationCards
  };
}

module.exports = {
  calculateRoomScore,
  getRecommendationForAQI,
  validateRoomInput,
  analyzeRoom,
  analyzeRoomBatch
};
